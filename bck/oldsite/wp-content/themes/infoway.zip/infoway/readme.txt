Thank you for trying the Infoway Wordpress Theme.

To Install infoway  Theme, Put the "infoway" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

The Theme installs with the basic layout in place. You can configure the Home Page using the Themes Options Panel.


Complete Theme Documentation in PDF & Video Format is Available at InkThemes.com

If you have any questions that are beyond the scope of this help file, You can Mail Us at enquiry@inkthemes.com