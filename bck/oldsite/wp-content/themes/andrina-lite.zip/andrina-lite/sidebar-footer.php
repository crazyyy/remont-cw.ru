<div class="grid_6 alpha">
    <div class="widget_inner">
        <?php if (is_active_sidebar('first-footer-widget-area')) : ?>
            <?php dynamic_sidebar('first-footer-widget-area'); ?>       
        <?php endif; ?>
    </div>
    


</div>
<div class="grid_7">
    <div class="widget_inner">
        <?php if (is_active_sidebar('second-footer-widget-area')) : ?>
            <?php dynamic_sidebar('second-footer-widget-area'); ?>               
        <?php endif; ?>
    </div>
    
    <body>

<body/>

</div>
<div class="grid_11 omega">
    <div class="widget_inner last">
        <?php if (is_active_sidebar('third-footer-widget-area')) : ?>
            <?php dynamic_sidebar('third-footer-widget-area'); ?>               
        <?php endif; ?>
    </div>
</div>
<div class="clear"></div>
    <div>
<!-- LiveTex {literal} -->
<script type='text/javascript'>
    var liveTex = true,
    liveTexID = 71640,
    liveTex_object = true;
    (function() {
    var lt = document.createElement('script');
    lt.type ='text/javascript';
    lt.async = true;
    lt.src = '//cs15.livetex.ru/js/client.js';
    var sc = document.getElementsByTagName('script')[0];
    if ( sc ) sc.parentNode.insertBefore(lt, sc);
    else document.documentElement.firstChild.appendChild(lt);
    })();
</script>
<!-- LiveTex {/literal} -->
</div>

